package com.example.log;

public class FoodOfferCalculate {
}
