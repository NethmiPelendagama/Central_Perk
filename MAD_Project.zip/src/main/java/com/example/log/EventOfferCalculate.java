package com.example.log;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class EventOfferCalculate extends AppCompatActivity {

    EditText et_packs, et_guestNo, et_ballRoom;
    Button event_btn_calculate;
    TextView event_answer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_offer_calculate);

        et_packs = findViewById(R.id.packs_input);
        et_guestNo = findViewById(R.id.guestNo_input);
        et_ballRoom = findViewById(R.id.ballRoom_input);


        event_btn_calculate = findViewById(R.id.event_btn_cal);
        event_answer = findViewById(R.id.event_answer);
    }

    @Override
    protected void onResume() {
        super.onResume();
        event_btn_calculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calculateEventDiscount();
            }
        });
    }

    public void calculateEventDiscount() {
        String packNum, guestNum, ballRoomNum;
        int pNum, gNum, bNum;

        EventCalculation cal = new EventCalculation();

        packNum = et_packs.getText().toString();
        guestNum = et_guestNo.getText().toString();
        ballRoomNum = et_ballRoom.getText().toString();


        //validations
        if(TextUtils.isEmpty(packNum)){
            et_packs.setError("Enter the selected package number");
        }
        else if(TextUtils.isEmpty(ballRoomNum)){
            et_ballRoom.setError("Enter the selected ballroom number");
        }
        else if(TextUtils.isEmpty(guestNum)){
            et_guestNo.setError("Enter the number of guests number");
        }

        else{

            pNum = Integer.parseInt(packNum);
            gNum = Integer.parseInt(guestNum);
            bNum = Integer.parseInt(ballRoomNum);

            String answer = cal.calculateEventDiscount(pNum, gNum, bNum);

            event_answer.setText(answer);
        }

    }
}