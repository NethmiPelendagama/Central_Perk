package com.example.log;

public class EventCalculation {
    protected String calculateEventDiscount(int packs, int guestNo, int ballRoom){
        int packPrize, ballRoomPrize,eventRate;

        double eventDiscount, eventPay, eventTotal;
        String eDiscount, ePayment, eTotal;


        switch(packs){
            case 1:
                packPrize = 4000;
                break;
            case 2:
                packPrize = 3500;
                break;
            case 3:
                packPrize = 3000;
                break;
            default:
                packPrize = 0;
                break;
        }

        switch(ballRoom){
            case 1:
                ballRoomPrize = 50000;
                break;
            case 2:
                ballRoomPrize = 45000;
                break;
            case 3:
                ballRoomPrize = 40000;
                break;
            default:
                ballRoomPrize = 0;
                break;
        }

        eventTotal = (packPrize * guestNo) + ballRoomPrize;

        if(guestNo >= 300){
            eventRate = 50;
        }
        else if(guestNo >= 250){
            eventRate = 25;
        }
        else if(guestNo >= 200){
            eventRate = 10;
        }
        else{
            eventRate = 0;
        }

        eventDiscount = eventTotal * (eventRate/100.0);
        eventPay = eventTotal - eventDiscount;

        eDiscount = String.format("Rs%.2f", eventDiscount);
        ePayment = String.format("Rs%.2f", eventPay);
        eTotal = String.format("Rs%.2f", eventTotal);


        String answer = "Total  :  " +eTotal+ "\nDiscount  :  " +eventRate+ "% off" + "\nDiscount Amount  :  " +eDiscount+ "\nAmount Payable  :  " +ePayment;
        return answer;
    }
}